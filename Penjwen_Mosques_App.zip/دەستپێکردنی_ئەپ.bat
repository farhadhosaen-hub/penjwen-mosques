@echo off
chcp 65001 > nul
title ئەپی فەرمی مزگەوتەکانی پێنجوێن
echo ======================================================
echo    ئەپی فەرمی مزگەوتەکانی پێنجوێن (ئۆفلاین 100%%)
echo ======================================================
echo تکایە چاوەڕوان بە... ئەپەکە لە وێبگەڕ دەکرێتەوە.
if exist "%~dp0Penjwen_Mosques_App.html" (
    start "" "%~dp0Penjwen_Mosques_App.html"
) else (
    start "" "%~dp0index.html"
)
exit
